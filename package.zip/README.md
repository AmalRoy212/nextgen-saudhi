- Create React App
- Configured Tailwind Css

# Features 
- Header
- Main Theme - Title & Description & Background Image
- About Conference
- Featured Speakers
- Industry Section
- Who Should Attend
- Registration form


